#define UDI_VERSION 0x101

#include <udi.h>

udi_init_t udi_init_info = { NULL };

void
sp_driver() {
}
